﻿using System;
using System.Collections.Generic;

namespace adres_api.Entities;

public partial class Iller
{
    public int IlId { get; set; }

    public string? IlAdi { get; set; }
}
